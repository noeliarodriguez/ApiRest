CREATE PROCEDURE `Usuario_Igual_Usr_Pw`(IN `_Name_User` VARCHAR(10), IN `_Pw_User` VARCHAR(300))
  BEGIN
    SELECT
      IFNULL(Id_Usuario,0) Id_Usuario,
      IFNULL(Name_User,'') Name_User,
      IFNULL(Nombre,'') Nombre,
      IFNULL(Apellido,'') Apellido,
      IFNULL(Email,'') Email,
      ifnull(Fecha_Nacimiento,'01-01-1900') Fecha_Nacimiento,
      ifnull(Telefono,0) Telefono,
      ifnull(Celular,0) Celular,
      ifnull(Fecha_Creacion,now()) Fecha_Creacion,
      ifnull(Fecha_Logueo,now()) Fecha_Logueo,
      ifnull(Esta_Logueado,0) Esta_Logueado,
      ifnull(Rol.Descripcion,'') Rol,
      ifnull(estados.Descripcion,'') Estado
    FROM  Usuario
      LEFT JOIN Estados on Usuario.Id_Estado = estados.Id_Estado
      LEFT JOIN Rol on usuario.Id_Rol = Rol.Id_Rol
    where Name_User = _Name_User and Pw_User = _Pw_User;
  END