CREATE PROCEDURE `Proveedor_Igual_Codigo`(IN `_Codigo` INT(11))
  BEGIN
    SELECT
      IFNULL(Proveedor.Id,0) Codigo,
      IFNULL(Razon_Social,'') Razon_Social,
      IFNULL(Cuit,0) Cuit,
      IFNULL(Nro_Ing_Brutos,0) Nro_Ing_Brutos,
      IFNULL(tipo_iva.Descripcion,'') IVA,
      ifnull(rubro_proveedor.Descripcion,'') Rubro,
      ifnull(pais.Descripcion,'') Pais,
      ifnull(provincia.Descripcion,'') Provincia,
      ifnull(Localidad,'') Localidad,
      ifnull(Barrio,'') Barrio,
      ifnull(Codigo_Postal,'') Codigo_Postal,
      ifnull(Email,'') Email,
      ifnull(Pagina_Web,'') Pagina_Web,
      ifnull(Domicilio,'') Domicilio,
      ifnull(Telefono,'') Telefono,
      ifnull(Celular,'') Celular,
      ifnull(Fax,'') Fax,
      ifnull(Observaciones,'') Observaciones
    FROM  proveedor
      LEFT JOIN tipo_iva on proveedor.Id_Iva = tipo_iva.Id
      LEFT JOIN rubro_proveedor on proveedor.Id_Rubro = rubro_proveedor.Id
      LEFT JOIN Pais on proveedor.Id_Pais = pais.Id_Pais
      LEFT JOIN provincia on proveedor.Id_Provincia = provincia.Id
    where Proveedor.Id = _Codigo
    ORDER BY Razon_Social;
  END