CREATE PROCEDURE `Usuario_Insert`(IN `_Name_User`    VARCHAR(10), IN `_Pw_User` VARCHAR(300), IN `_Nombre` VARCHAR(50),
                                  IN `_Apellido`     VARCHAR(50), IN `_Email` VARCHAR(50), IN `_Fecha_Nacimiento` DATE,
                                  IN `_Telefono`     INT(11), IN `_Celular` INT(11), IN `_Fecha_Creacion` DATETIME,
                                  IN `_Fecha_Logueo` DATETIME, IN `_Esta_Logueado` TINYINT(1), IN `_Id_Rol` INT(11),
                                  IN `_Id_Estado`    INT(11))
  BEGIN
    INSERT INTO Usuario
    (Name_User, Pw_User, Nombre, Apellido, Email, Fecha_Nacimiento, Telefono, Celular, Fecha_Creacion, Fecha_Logueo, Esta_Logueado, Id_Rol, Id_Estado)
    VALUES
      (_Name_User,_Pw_User,_Nombre,_Apellido,_Email,_Fecha_Nacimiento,_Telefono,_Celular,_Fecha_Creacion,_Fecha_Logueo,_Esta_Logueado,_Id_Rol,_Id_Estado);
  END